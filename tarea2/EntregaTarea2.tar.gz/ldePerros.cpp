#include "../include/ldePerros.h"

struct rep_tldeperros {

};

TLDEPerros crearTLDEPerrosVacia(){
    return NULL;
}

void insertarTLDEPerros(TLDEPerros &ldePerros, TPerro perro){

}

void liberarTLDEPerros(TLDEPerros &ldePerros){

}

void imprimirTLDEPerros(TLDEPerros ldePerros){

}

void imprimirInvertidoTLDEPerros(TLDEPerros ldePerros){

}

nat cantidadTLDEPerros(TLDEPerros ldePerros){
    return 0;
}

TPerro removerPerroTLDEPerros(TLDEPerros &ldePerros, int id){
    return NULL;
}

TPerro obtenerPrimeroTLDEPerros(TLDEPerros ldePerros){
    return NULL;
}

TPerro obtenerUltimoTLDEPerros(TLDEPerros ldePerros){
    return NULL;
}

TPerro obtenerNesimoTLDEPerros(TLDEPerros ldePerros, int n){
    return NULL;
}

bool existePerroTLDEPerros(TLDEPerros ldePerros, int id){
    return false;
}

