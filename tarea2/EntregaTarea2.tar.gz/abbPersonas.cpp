
#include "../include/abbPersonas.h"

struct rep_abbPersonas {
};

TABBPersonas crearTABBPersonasVacio(){
    return NULL;
}

void insertarTPersonaTABBPersonas(TABBPersonas &abbPersonas, TPersona persona){

}

void imprimirTABBPersonas(TABBPersonas abbPersonas){

}

void liberarTABBPersonas(TABBPersonas &abbPersonas){

}

bool existeTPersonaTABBPersonas(TABBPersonas abbPersonas, int ciPersona){
    return false;
}

TPersona obtenerTPersonaTABBPersonas(TABBPersonas abbPersonas, int ciPersona){
    return NULL;
}

nat alturaTABBPersonas(TABBPersonas abbPersonas){
    return 0;
}

TPersona maxCITPersonaTABBPersonas(TABBPersonas abbPersonas){
    return NULL;
}

void removerTPersonaTABBPersonas(TABBPersonas &abbPersonas, int ciPersona){

}

int cantidadTABBPersonas(TABBPersonas abbPersonas){
    return 0;
}

TPersona obtenerNesimaPersonaTABBPersonas(TABBPersonas abbPersonas, int n){
    return NULL;
}

TABBPersonas filtradoPorFechaDeNacimientoTABBPersonas(TABBPersonas abbPersonas, TFecha fecha, int criterio){
    return NULL;
}